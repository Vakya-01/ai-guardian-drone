AI GUARDIAN DRONE — SOS DEMO V2

WHAT IS DIFFERENT:
The police page creates a NEW session ID every time it opens.
It then automatically creates an SOS link and QR code containing that session ID.
The parent scans that QR code, so their SOS page connects specifically to that police dashboard.

DEMO:
1. Host BOTH index.html and police.html on the same HTTPS website.
2. Open police.html on the phone that will act as the police station.
3. Tap "Enable Siren" once.
4. Wait for "SYSTEM ONLINE" and the QR code.
5. Parent scans the QR code.
6. Parent should see "Connected to demonstration police station".
7. Press SOS.
8. Police phone shows SOS ALERT RECEIVED and plays a 10-second siren.

IMPORTANT:
- Internet is required on both phones.
- Keep police.html open during the demo.
- Browser sound permissions require the police user to tap Enable Siren.
- This is a school prototype. It does not contact real police/emergency services.
- The QR code is generated automatically by the police webpage; you do not need to make it manually.
- The project uses PeerJS for the demonstration connection and QRCode.js for QR generation.
